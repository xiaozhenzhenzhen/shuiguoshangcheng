// pages/mycar/mycar.js
const sc = wx.cloud.database();
Page({
    
  /**
   * 页面的初始数据
   */
  data: {
    mycar:[],
    total:"",
    num:1
  },
  // 增加数量
  addCount(e) {
    const index = e.currentTarget.dataset._id;
    let num = this.data.num;
    num = num + 1;
    this.setData({
      num:num
    });
  },
  // 减少数量
  minusCount(e) {
    const index = e.currentTarget.dataset._id;
    let num = this.data.num;
    if (num <= 1) {
      return false;
    }
    num = num - 1;
    this.setData({
      num:num
    });
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
     let carts=this.data.mycar;
     


    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
      
      
    wx.getStorage({
      key: 'openid',
      success: (res) => {
        console.log(res.data);
        //获取购物车数据
        sc.collection("mycar").where({ useropenid: res.data }).get().then(res => {
          console.log(res.data);
          var sum=0;
          //遍历购物车商品价格
          for(var item of res.data){
            sum+=item.cc*1;  
          }
          sum*=100;
          this.setData({ total: sum })
          this.setData({
            mycar: res.data
          })
        }).catch(err => {
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})